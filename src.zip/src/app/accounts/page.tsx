import EmailSendersView from '@/components/views/EmailSendersView';
export default EmailSendersView;