import CampaignsView from '@/components/views/CampaignsView';
export default CampaignsView;
