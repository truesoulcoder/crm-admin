import SettingsView from '@/components/views/SettingsView';
export default SettingsView;