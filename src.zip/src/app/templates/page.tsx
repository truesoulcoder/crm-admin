import TemplatesView from '@/components/views/TemplatesView';
export default TemplatesView;