// Type declaration for crypto-js module
declare module 'crypto-js';
